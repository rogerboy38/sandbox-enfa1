@extends('website.layout')

@section('content')
<div class="container">
	<div class="col-sm-12 trans-blk">
		body_generic
	</div>
</div>
@stop