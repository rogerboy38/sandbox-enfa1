@extends('website.layout')

    @section('content')
                                                                                                <div><br></div><div><font size="3" face="trebuchet ms">Paso 1</font><div><font size="3" face="trebuchet ms">Registra tu tarjeta de crédito o débito.</font></div><div><font size="3" face="trebuchet ms"><br></font></div><div><font size="3" face="trebuchet ms">Paso 2</font></div><div><font size="3" face="trebuchet ms">Si tienes un código promocional, agrégalo donde te lo solicite.</font></div><div><font size="3" face="trebuchet ms"><br></font></div><div><font size="3" face="trebuchet ms">Paso 3</font></div><div><font size="3" face="trebuchet ms">Selecciona el tipo de servicio que requieres.&nbsp;<span style="line-height: 1.42857;">Confirma el servicio y&nbsp;</span><span style="line-height: 1.42857;">Dale seguimiento.</span></font></div><div><span style="line-height: 1.42857;"><font size="3" face="trebuchet ms"><br></font></span></div><div><span style="line-height: 1.42857;"><font size="3" face="trebuchet ms">Paso 4</font></span></div><div><font size="3" face="trebuchet ms">Cuando el servicio esté completado, recibirás tu recibo/factura. Dale clic en confirmar.</font></div><div><font size="3" face="trebuchet ms"><br></font></div><div><font size="3" face="trebuchet ms">Paso 5</font></div><div><font size="3" face="trebuchet ms">Califica a tu Kourer.</font></div><div><font size="3" face="trebuchet ms">Listo!</font></div>  
                                        </div>  
                                          
                                          
                                        
    @stop

