@extends('website.layout')

    @section('content')
        Este texto es de una prueba
    @stop

